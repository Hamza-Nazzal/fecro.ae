// src/components/BuyerRFQDetail.jsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useParams, Link } from "react-router-dom";
import {
  Building2,
  CalendarClock,
  Eye,
  MessageSquareText,
  Package,
  Tag,
} from "lucide-react";

// Preferred services (guarded requires so this file never crashes if a function is missing)
import { listRFQsForCards } from "../services/rfqService/reads";

let getRFQByIdSafe = null;
try {
  // If you already have a specific getter, it will be used.
  // eslint-disable-next-line global-require
  getRFQByIdSafe = require("../services/rfqService/reads").getRFQById;
} catch (_) { /* optional */ }

let listQuotationsForRFQ = null;
let acceptQuotation = null;
let rejectQuotation = null;
try {
  // eslint-disable-next-line global-require
  const svc = require("../services/quotationsService");
  listQuotationsForRFQ = svc.listQuotationsForRFQ;
  acceptQuotation = svc.acceptQuotation;
  rejectQuotation = svc.rejectQuotation;
} catch (_) { /* optional */ }

// Small UI helpers
function Chip({ icon: Icon, children }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs bg-slate-100 text-slate-700">
      {Icon ? <Icon className="w-3 h-3" /> : null}
      {children}
    </span>
  );
}

function StatusBadge({ status }) {
  if (!status) return null;
  const map = {
    accepted: "bg-green-50 text-green-700 ring-1 ring-green-200",
    rejected: "bg-red-50 text-red-700 ring-1 ring-red-200",
    pending: "bg-slate-50 text-slate-700 ring-1 ring-slate-200",
  };
  const cls = map[status] || map.pending;
  return (
    <span className={`rounded-full px-2 py-0.5 text-xs ${cls}`}>
      {String(status).toUpperCase()}
    </span>
  );
}

function ItemRow({ item }) {
  return (
    <div className="grid grid-cols-12 items-center gap-3 rounded-lg border border-slate-100 bg-white p-2">
      <div className="col-span-5 flex items-center gap-2 truncate">
        <Package className="w-4 h-4 text-slate-500" />
        <span className="truncate font-medium">{item.name}</span>
      </div>
      <div className="col-span-2 text-slate-700">
        <span className="font-medium">{item.quantity}</span>
        <span className="ml-1 text-slate-500">{item.unit}</span>
      </div>
      <div className="col-span-4 truncate text-slate-600">
        {item.categoryPath || "—"}
      </div>
      <div className="col-span-1 flex justify-end">
        <Chip icon={Tag}>{item.attrsCount ?? 0}</Chip>
      </div>
    </div>
  );
}

export default function BuyerRFQDetail() {
  const { rfqId } = useParams();

  const [rfq, setRfq] = useState(null);
  const [quotes, setQuotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [qLoading, setQLoading] = useState(true);
  const [error, setError] = useState(null);
  const [qError, setQError] = useState(null);

  // Action state
  const [actionBusyId, setActionBusyId] = useState(null);
  const [actionErr, setActionErr] = useState(null);
  const [awardedQuoteId, setAwardedQuoteId] = useState(null); // lock others after accept

  const reqRef = useRef(0);

  // Fetch RFQ
  useEffect(() => {
    let alive = true;
    const myReq = ++reqRef.current;

    (async () => {
      try {
        setLoading(true);
        setError(null);

        let row = null;

        // 1) Dedicated getter if available
        if (getRFQByIdSafe) {
          row = await getRFQByIdSafe(rfqId);
        }

        // 2) Fallback: small page filtered by id/publicId (if supported)
        if (!row) {
          const res = await listRFQsForCards({ rfqId, page: 1, pageSize: 1 });
          const data = Array.isArray(res) ? res : res?.data;
          row = data?.[0] || null;
        }

        if (!alive || myReq !== reqRef.current) return;
        setRfq(row);
      } catch (e) {
        if (!alive || myReq !== reqRef.current) return;
        setError(e?.message || String(e));
        setRfq(null);
      } finally {
        if (!alive || myReq !== reqRef.current) return;
        setLoading(false);
      }
    })();

    return () => {
      alive = false;
    };
  }, [rfqId]);

  // Fetch quotations for this RFQ (buyer view)
  useEffect(() => {
    let alive = true;
    (async () => {
      if (!rfqId) return;
      try {
        setQLoading(true);
        setQError(null);

        let rows = [];
        if (listQuotationsForRFQ) {
          rows = await listQuotationsForRFQ(rfqId);
        } else {
          rows = []; // fallback until service is wired
        }

        if (!alive) return;
        const list = Array.isArray(rows) ? rows : rows?.data || [];

        setQuotes(list);
        // Pre-fill awardedQuoteId if any quote already accepted
        const pre = list.find((q) => (q.status || "").toLowerCase() === "accepted");
        if (pre) setAwardedQuoteId(pre.id);
      } catch (e) {
        if (!alive) return;
        setQError(e?.message || String(e));
        setQuotes([]);
      } finally {
        if (!alive) return;
        setQLoading(false);
      }
    })();

    return () => {
      alive = false;
    };
  }, [rfqId]);

  const metaChips = useMemo(() => {
    if (!rfq) return null;
    return (
      <div className="mt-1 flex flex-wrap items-center gap-2 text-sm text-slate-600">
        <Chip icon={Building2}>{rfq.buyer?.name || "—"}</Chip>
        <Chip icon={Eye}>{rfq.views ?? 0} views</Chip>
        <Chip icon={MessageSquareText}>{rfq.quotationsCount ?? 0} quotes</Chip>
        {rfq.postedAt && (
          <Chip icon={CalendarClock}>
            Posted {new Date(rfq.postedAt).toLocaleDateString()}
          </Chip>
        )}
        {rfq.deadline && (
          <Chip icon={CalendarClock}>
            Due {new Date(rfq.deadline).toLocaleDateString()}
          </Chip>
        )}
      </div>
    );
  }, [rfq]);

  async function handleDecision(q, targetStatus) {
    setActionErr(null);
    setActionBusyId(q.id);
    try {
      if (targetStatus === "accepted") {
        if (acceptQuotation) {
          await acceptQuotation({ quotationId: q.id, rfqId });
        } else {
          // fallback log
          // eslint-disable-next-line no-console
          console.log("acceptQuotation (fallback)", { quotationId: q.id, rfqId });
        }
        // Optimistic UI: mark this quote accepted and lock others
        setQuotes((prev) =>
          prev.map((row) =>
            row.id === q.id ? { ...row, status: "accepted" } : row
          )
        );
        setAwardedQuoteId(q.id);
        // Optional: mark RFQ status locally
        setRfq((prev) => (prev ? { ...prev, status: "awarded" } : prev));
        // Broadcast
        window.dispatchEvent(
          new CustomEvent("quotation:decision", {
            detail: { rfqId, quotationId: q.id, status: "accepted" },
          })
        );
      } else if (targetStatus === "rejected") {
        if (rejectQuotation) {
          await rejectQuotation({ quotationId: q.id, rfqId });
        } else {
          // fallback log
          // eslint-disable-next-line no-console
          console.log("rejectQuotation (fallback)", { quotationId: q.id, rfqId });
        }
        setQuotes((prev) =>
          prev.map((row) =>
            row.id === q.id ? { ...row, status: "rejected" } : row
          )
        );
        window.dispatchEvent(
          new CustomEvent("quotation:decision", {
            detail: { rfqId, quotationId: q.id, status: "rejected" },
          })
        );
      }
    } catch (err) {
      setActionErr(err?.message || String(err));
    } finally {
      setActionBusyId(null);
    }
  }

  return (
    <div className="p-4">
      <div className="mb-3 flex items-center justify-between">
        <Link to="/buyer/rfqs" className="text-blue-600 hover:underline text-sm">
          ← Back to My RFQs
        </Link>
        {!!rfq?.publicId && (
          <span className="text-xs text-slate-500">RFQ ID: {rfq.publicId}</span>
        )}
      </div>

      {loading ? (
        <div className="text-slate-500">Loading RFQ…</div>
      ) : error ? (
        <div className="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700">
          {String(error)}
        </div>
      ) : !rfq ? (
        <div className="rounded-md border border-slate-200 bg-white p-4">Not found.</div>
      ) : (
        <>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-semibold">{rfq.title || "Untitled RFQ"}</h1>
            {rfq.status && <StatusBadge status={rfq.status} />}
          </div>
          {metaChips}

          {/* Items */}
          <section className="mt-4">
            <h2 className="mb-2 text-sm font-semibold text-slate-700">Items</h2>
            <div className="grid grid-cols-12 items-center gap-3 text-xs uppercase tracking-wide text-slate-500">
              <div className="col-span-5">Item</div>
              <div className="col-span-2">Qty</div>
              <div className="col-span-4">Category</div>
              <div className="col-span-1 text-right">Specs</div>
            </div>
            <div className="mt-2 space-y-2">
              {(rfq.items || []).map((it, idx) => (
                <ItemRow key={idx} item={it} />
              ))}
            </div>
          </section>

          {/* Notes */}
          {rfq.notes && (
            <section className="mt-4">
              <h2 className="mb-2 text-sm font-semibold text-slate-700">Notes</h2>
              <div className="rounded-xl bg-slate-50 p-3 text-sm text-slate-700">
                {rfq.notes}
              </div>
            </section>
          )}

          {/* Quotations */}
          <section className="mt-6">
            <div className="mb-2 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-700">Quotations</h2>
              <button
                className="rounded-lg border px-3 py-1.5 text-sm hover:bg-slate-50"
                onClick={() => window.dispatchEvent(new Event("quotation:refresh"))}
              >
                Refresh
              </button>
            </div>

            {actionErr && (
              <div className="mb-3 rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700">
                {String(actionErr)}
              </div>
            )}

            {qLoading ? (
              <div className="text-slate-500">Loading quotations…</div>
            ) : qError ? (
              <div className="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700">
                {String(qError)}
              </div>
            ) : (quotes || []).length === 0 ? (
              <div className="rounded-xl border bg-white p-6 text-center text-slate-500">
                No quotations yet.
              </div>
            ) : (
              <div className="grid gap-3">
                {quotes.map((q) => {
                  const isAccepted = (q.status || "").toLowerCase() === "accepted";
                  const isRejected = (q.status || "").toLowerCase() === "rejected";
                  const lockOthers = awardedQuoteId && q.id !== awardedQuoteId;

                  return (
                    <div
                      key={q.id}
                      className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <div className="text-sm font-semibold">
                              {q.seller?.company || q.seller?.name || "Seller"}
                            </div>
                            <StatusBadge status={q.status || "pending"} />
                          </div>
                          <div className="text-xs text-slate-500">
                            Submitted{" "}
                            {q.created_at
                              ? new Date(q.created_at).toLocaleString()
                              : "—"}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-base font-semibold">
                            {q.currency || "AED"}{" "}
                            {Number(q.total_amount || q.amount || 0).toLocaleString(
                              "en-US",
                              { minimumFractionDigits: 2 }
                            )}
                          </div>
                          {q.lead_time_days != null && (
                            <div className="text-xs text-slate-500">
                              Lead time: {q.lead_time_days} day
                              {q.lead_time_days === 1 ? "" : "s"}
                            </div>
                          )}
                        </div>
                      </div>

                      {q.notes && (
                        <div className="mt-2 rounded-md bg-slate-50 p-2 text-sm text-slate-700">
                          {q.notes}
                        </div>
                      )}

                      <div className="mt-3 flex gap-2">
                        <button
                          className="rounded-lg bg-blue-600 px-3 py-1.5 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50"
                          onClick={() => handleDecision(q, "accepted")}
                          disabled={
                            actionBusyId === q.id ||
                            isAccepted ||
                            lockOthers
                          }
                        >
                          {actionBusyId === q.id && !isRejected ? "Working…" : "Accept"}
                        </button>
                        <button
                          className="rounded-lg border px-3 py-1.5 text-sm hover:bg-slate-50 disabled:opacity-50"
                          onClick={() => handleDecision(q, "rejected")}
                          disabled={actionBusyId === q.id || isRejected || lockOthers}
                        >
                          {actionBusyId === q.id && !isAccepted ? "Working…" : "Reject"}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
}

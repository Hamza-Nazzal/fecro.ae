// src/services/rfqService/reads.js

import { supabase } from "../backends/supabase";
import { getCurrentUserCached } from "../backends/supabase/auth";
import { mapRFQRow } from "./mapping";


//  ADD THIS: one-time warning helper
const __warned = new Set();
function warnOnce(key, msg) {
  if (__warned.has(key)) return;
  __warned.add(key);
  // eslint-disable-next-line no-console
  console.warn(msg);
}

/** List RFQs (hydrated: items + specs via FK embedding) */
export async function listRFQs({ onlyOpen, userId, search } = {}) {
  // ADD THIS LINE:
  warnOnce(
    "HEAVY_LIST_RFQS",
    "[rfqService] listRFQs: heavy hydrated query used (items+specs embed). Prefer listRFQsForCards() in list UIs."
  );

  let q = supabase
    .from("rfqs")
    .select(
      "*, categories:category_id(name, path_text), rfq_items(*, rfq_item_specs!rfq_item_specs_rfq_item_id_fkey(*))"
    )
    .order("posted_time", { ascending: false });

  if (onlyOpen) q = q.eq("status", "active");
  if (userId) q = q.eq("user_id", userId);
  if (search) q = q.ilike("title", `%${search}%`);

  const { data, error } = await q;
  if (error) throw error;
  return (data || []).map(mapRFQRow);
}

/** List current user's RFQs (hydrated) */
export async function listMyRFQs() {
  //  ADD THIS LINE:
  warnOnce(
    "HEAVY_LIST_MY_RFQS",
    "[rfqService] listMyRFQs: heavy hydrated query used. Prefer listRFQsForCards({ buyerId }) in list UIs."
  );

  const user = await getCurrentUserCached();
  if (!user) {
    // eslint-disable-next-line no-console
    console.warn("[rfqService] listMyRFQs called without session – returning empty list");
    return [];
  }

  const { data, error } = await supabase
    .from("rfqs")
    .select(
      "*, categories:category_id(name, path_text), rfq_items(*, rfq_item_specs!rfq_item_specs_rfq_item_id_fkey(*))"
    )
    .eq("user_id", user.id)
    .order("posted_time", { ascending: false });

  if (error) throw error;
  return (data || []).map(mapRFQRow);
}

/** Single RFQ (fully hydrated) */
export async function getRFQ(id) {
  const { data, error } = await supabase
    .from("rfqs")
    .select(
      "*, categories:category_id(name, path_text), rfq_items(*, rfq_item_specs!rfq_item_specs_rfq_item_id_fkey(*))"
    )
    // explicit FK tag prevents PGRST201 if another FK appears later
    .eq("id", id)
    .single();
  if (error) throw error;
  return mapRFQRow(data);
}

/**
 * Lightweight fetch for RFQ cards using the v_rfqs_card view.
 * Returns items already shaped for the card UI:
 * { id, publicId, title, createdAt, status, quantity, categoryPath }
 */
export async function listRFQsForCards({
  buyerId,            // optional: when set, limits to that buyer (Buyer view)
  onlyOpen = false,   // optional: when true, filters status='active' (Seller/Browse interim)
  page = 1,
  pageSize = 20,
}) {
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  let q = supabase
    .from("v_rfqs_card")
    .select("id, public_id, title, created_at, status, buyer_id, qty_total, first_category_path")
    .order("created_at", { ascending: false })
    .range(from, to);

  if (buyerId) q = q.eq("buyer_id", buyerId);
  if (onlyOpen) q = q.eq("status", "active");

  const { data, error } = await q;
  if (error) throw new Error(error.message);

  // Map to existing card-friendly shape so your UI props keep working
  const rows = (data || []).map((r) => ({
    id: r.id,
    publicId: r.public_id,
    title: r.title,
    createdAt: r.created_at,
    status: r.status,
    quantity: r.qty_total ?? 0,
    categoryPath: r.first_category_path || "—",
    _raw: r,
  }));

  return { data: rows };
}


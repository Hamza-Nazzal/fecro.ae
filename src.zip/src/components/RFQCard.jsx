// src/components/RFQCard.jsx
import React, { useState } from "react";
import {
  Package,
  Tag,
  Building2,
  CalendarClock,
  Eye,
  MessageSquareText,
  ChevronRight,
  ChevronDown,
} from "lucide-react";

//import clsx from "clsx";



function clsx(...parts) {
  return parts.filter(Boolean).join(" ");
}


const STATUS_BADGE = {
  open: "bg-green-50 text-green-700 ring-1 ring-green-200",
  closed: "bg-gray-50 text-gray-700 ring-1 ring-gray-200",
  awarded: "bg-blue-50 text-blue-700 ring-blue-200",
};

function Chip({ icon: Icon, children }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs bg-slate-100 text-slate-700">
      {Icon ? <Icon className="w-3 h-3" /> : null}
      {children}
    </span>
  );
}

function ItemRow({ item }) {
  return (
    <div className="grid grid-cols-12 items-center gap-3 rounded-lg border border-slate-100 bg-white p-2">
      <div className="col-span-5 flex items-center gap-2 truncate">
        <Package className="w-4 h-4 text-slate-500" />
        <span className="truncate font-medium">{item.name}</span>
      </div>
      <div className="col-span-2 text-slate-700">
        <span className="font-medium">{item.quantity}</span>
        <span className="ml-1 text-slate-500">{item.unit}</span>
      </div>
      <div className="col-span-4 truncate text-slate-600">
        {item.categoryPath || "—"}
      </div>
      <div className="col-span-1 flex justify-end">
        <Chip icon={Tag}>{item.attrsCount ?? 0}</Chip>
      </div>
    </div>
  );
}

/**
 * Props:
 * - rfq: {...}
 * - onPrimary?: (rfq) => void        // new, preferred
 * - ctaLabel?: string                // defaults by role
 * - showCTA?: boolean                // default true
 * - role?: 'seller' | 'buyer'        // affects default CTA label
 * - onSendQuote?: (rfq) => void      // backward-compat (seller)
 */
export default function RFQCard({
  rfq,
  onPrimary,
  ctaLabel,
  showCTA = true,
  role = "seller",
  onSendQuote,
}) {
  const [open, setOpen] = useState(false);
  const hasMany = (rfq.items?.length || 0) > 2;
  const preview = rfq.items?.slice(0, 2) || [];
  const rest = rfq.items?.slice(2) || [];

  const primaryHandler = onPrimary || onSendQuote;
  const defaultLabel = role === "buyer" ? "View / Manage" : "Send Quote";
  const buttonLabel = ctaLabel || defaultLabel;

  return (
    <article className="rounded-2xl border border-slate-200 bg-white shadow-sm p-4">
      {/* Header */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="truncate text-base font-semibold">{rfq.title}</span>
            <span
              className={clsx(
                "rounded-full px-2 py-0.5 text-xs",
                STATUS_BADGE[rfq.status || "open"]
              )}
            >
              {rfq.status?.toUpperCase() || "OPEN"}
            </span>
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-2 text-sm text-slate-600">
            <Chip icon={Building2}>{rfq.buyer?.name || "—"}</Chip>
            <Chip icon={Eye}>{rfq.views ?? 0} views</Chip>
            <Chip icon={MessageSquareText}>
              {rfq.quotationsCount ?? 0} quotes
            </Chip>
            <Chip icon={CalendarClock}>
              Posted{" "}
              {rfq.postedAt
                ? new Date(rfq.postedAt).toLocaleDateString()
                : "—"}
            </Chip>
            {rfq.deadline && (
              <Chip icon={CalendarClock}>
                Due {new Date(rfq.deadline).toLocaleDateString()}
              </Chip>
            )}
          </div>
        </div>

        {showCTA && (
          <button
            onClick={() => primaryHandler?.(rfq)}
            className="rounded-xl bg-blue-600 px-3 py-2 text-sm font-semibold text-white shadow hover:bg-blue-700 disabled:opacity-60"
            disabled={!primaryHandler}
          >
            {buttonLabel}
          </button>
        )}
      </div>

      {/* Items */}
      <div className="mt-3 space-y-2">
        <div className="grid grid-cols-12 items-center gap-3 text-xs uppercase tracking-wide text-slate-500">
          <div className="col-span-5">Item</div>
          <div className="col-span-2">Qty</div>
          <div className="col-span-4">Category</div>
          <div className="col-span-1 text-right">Specs</div>
        </div>
        {preview.map((item, idx) => (
          <ItemRow key={idx} item={item} />
        ))}
        {hasMany && !open && (
          <button
            onClick={() => setOpen(true)}
            className="mt-1 inline-flex items-center gap-1 text-sm font-medium text-blue-700 hover:underline"
          >
            <ChevronRight className="w-4 h-4" /> Show {rest.length} more
          </button>
        )}
        {open &&
          rest.map((item, idx) => <ItemRow key={`rest-${idx}`} item={item} />)}
        {open && (
          <button
            onClick={() => setOpen(false)}
            className="mt-1 inline-flex items-center gap-1 text-sm font-medium text-blue-700 hover:underline"
          >
            <ChevronDown className="w-4 h-4" /> Hide items
          </button>
        )}
      </div>

      {/* Notes */}
      {rfq.notes && (
        <div className="mt-3 rounded-xl bg-slate-50 p-3 text-sm text-slate-700">
          {rfq.notes}
        </div>
      )}
    </article>
  );
}

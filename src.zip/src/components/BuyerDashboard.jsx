// src/components/BuyerDashboard.jsx
import React from "react";
import BuyerRFQsInline from "./BuyerRFQsInline";

export default function BuyerDashboard() {
  return (
    <div className="p-4">
      <BuyerRFQsInline />
    </div>
  );
}

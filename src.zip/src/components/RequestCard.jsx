//src/components/RequestCard.jsx
// RequestCard.jsx (UI-only + kebab, polished)
/*
1	UI card showing an RFQ (request) with title, categories, date, and quick actions.
	2	Clickable, accessible card with a kebab menu; safely formats dates and counts. 
  Pure UI, no data fetching.
*/
//src/components/RequestCard.jsx

import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  Package, Tag, CalendarClock, MessageSquare, Eye, AlertCircle, MoreVertical,
} from "lucide-react";

// helpers
const formatDate = (value) => {
  if (!value) return "—";
  try {
    const d = new Date(value);
    return isNaN(d.getTime())
      ? "—"
      : d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
  } catch {
    return "—";
  }
};

const pluralize = (n, one, many) => `${n} ${n === 1 ? one : many}`;

const statusStyles = {
  Open: "bg-green-50 text-green-700 border-green-200",
  Inactive: "bg-gray-100 text-gray-700 border-gray-200",
  Closed: "bg-black text-white border-black",
  Draft: "bg-amber-50 text-amber-800 border-amber-200",
};

const qtyText = (q, unit = "") => {
  if (q === 0) return `0${unit ? ` ${unit}` : ""}`;
  if (q === undefined || q === null || q === "") return "—";
  const n = Number(q);
  if (Number.isNaN(n)) return "—";
  const f = new Intl.NumberFormat("en-US").format(n);
  return unit ? `${f} ${unit}` : f;
};

function RequestCard({
  title = "Office Notebooks — Bulk Order", 
  rfqId,
  qty,
  unit = "",
  category = "—",
  subCategory = "",
  categoryPath,
  postedAt,
  quotations = 0,
  views = 0,
  status = "Open",
  onClick,
  onStatusChange,
  onEdit,
  onDelete,
  ctaLabel = "View quotations",
}) {
  const [openMenu, setOpenMenu] = useState(false);
  const menuRef = useRef(null);

  // Only memoize the expensive menu computation
  const menuOptions = useMemo(() => {
    const opts = [];
    if (status === "Open") {
      if (onStatusChange) opts.push({ label: "Pause", action: () => onStatusChange("Draft") });
      if (onStatusChange) opts.push({ label: "Close", action: () => onStatusChange("Closed") });
      if (onDelete) opts.push({ label: "Delete", action: onDelete, danger: true });
    } else if (status === "Draft") {
      if (onStatusChange) opts.push({ label: "Resume", action: () => onStatusChange("Open") });
      if (onEdit) opts.push({ label: "Edit", action: onEdit });
      if (onStatusChange) opts.push({ label: "Close", action: () => onStatusChange("Closed") });
      if (onDelete) opts.push({ label: "Delete", action: onDelete, danger: true });
    } else if (status === "Closed") {
      if (onEdit) opts.push({ label: "Re-request", action: onEdit });
      if (onDelete) opts.push({ label: "Delete", action: onDelete, danger: true });
    }
    return opts;
  }, [status, onStatusChange, onEdit, onDelete]);

  // Simple computations - no memoization needed
  const dateText = formatDate(postedAt);
  const showSub = !categoryPath && subCategory && subCategory.toLowerCase() !== "n/a";
  const categoryDisplay = categoryPath || category || "—";
  const hasInvalidDate = dateText === "—" && postedAt;

  // close on outside click / Esc
  useEffect(() => {
    if (!openMenu) return;
    const onDoc = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setOpenMenu(false);
    };
    const onKey = (e) => { if (e.key === "Escape") setOpenMenu(false); };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onKey);
    };
  }, [openMenu]);

  return (
    <article
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      onClick={onClick}
      onKeyDown={onClick ? (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onClick();
        }
      } : undefined}
      className="group rounded-2xl border border-gray-200 bg-white shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-blue-600/40 transition"
    >
      {/* Header strip */}
      <div className="relative rounded-t-2xl bg-blue-50/60 px-5 py-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
            {rfqId && (
              <div className="mt-1 inline-flex items-center gap-2 rounded-md border border-blue-200 bg-white/70 px-2 py-0.5 text-xs font-medium text-blue-700">
                {rfqId}
               </div>
            )}
            <div className="mt-1 flex items-center gap-2 text-sm text-gray-700">
              <Package className="h-4 w-4 text-gray-500" />
              <span className="tabular-nums">Qty: {qtyText(qty, unit)}</span>
            </div>
          </div>

          {/* Kebab */}
          <div className="relative" ref={menuRef} onClick={(e) => e.stopPropagation()}>
            <button
              type="button"
              aria-haspopup="menu"
              aria-expanded={openMenu}
              aria-label="More actions"
              onClick={() => setOpenMenu((s) => !s)}
              className="p-1 hover:bg-blue-100 rounded-full transition-colors"
              title="More actions"
            >
              <MoreVertical className="h-4 w-4 text-gray-600" />
            </button>

            {openMenu && menuOptions.length > 0 && (
              <div
                role="menu"
                className="absolute right-0 top-full z-50 mt-1 w-40 overflow-hidden rounded-lg border border-gray-200 bg-white shadow-lg"
              >
                {menuOptions.map((opt, i) => (
                  <button
                    key={`${opt.label}-${i}`}
                    role="menuitem"
                    onClick={(e) => { e.stopPropagation(); setOpenMenu(false); opt.action?.(); }}
                    className={`w-full px-3 py-2 text-left text-sm hover:bg-gray-50 first:rounded-t-lg last:rounded-b-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-inset ${
                      opt.danger ? "text-red-600 hover:bg-red-50" : "text-gray-700"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Body */}
      <div className="px-5 py-4">
        {/* Meta row */}
        <div className="flex flex-col gap-2 text-sm text-gray-700 md:flex-row md:flex-wrap md:items-center md:gap-x-6">
          <div className="flex items-center gap-2">
            <Tag className="h-4 w-4 text-gray-500" />
            <span className="text-gray-600">
              <span className="text-gray-900">Category:</span> {categoryDisplay}
              {showSub && (
                <span className="ml-3">
                  <span className="text-gray-900">Sub-category:</span> {subCategory}
                </span>
              )}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <CalendarClock className="h-4 w-4 text-gray-500" />
            <span className="text-gray-600">
              <span className="text-gray-900">Posted:</span> {dateText}
            </span>
            {hasInvalidDate && (
              <AlertCircle className="h-4 w-4 text-amber-500" title="Provided date was invalid" />
            )}
          </div>

          <div className="ml-0 flex items-center gap-4 md:ml-auto">
            <div className="flex items-center gap-1.5" aria-label={`${quotations} quotations`}>
              <MessageSquare className="h-4 w-4 text-gray-500" />
              <span className="text-gray-700">{pluralize(quotations, "quotation", "quotations")}</span>
            </div>
            <div className="flex items-center gap-1.5" aria-label={`${views} views`}>
              <Eye className="h-4 w-4 text-gray-500" />
              <span className="text-gray-700">{pluralize(views, "view", "views")}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-4 flex items-center justify-between">
          <span
            className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-medium ${
              statusStyles[status] || statusStyles.Inactive
            }`}
            title={status}
          >
            {status}
          </span>

          <button
            className="inline-flex items-center rounded-lg bg-blue-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            onClick={(e) => { e.stopPropagation(); onClick?.(); }}
          >
            {ctaLabel}
          </button>
        </div>
      </div>
    </article>
  );
}

export default React.memo(RequestCard);
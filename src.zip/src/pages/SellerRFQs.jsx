// src/pages/SellerRFQs.jsx
import React from "react";
import SellerRFQsInline from "../components/SellerRFQsInline";

export default function SellerRFQsPage() {
  return <SellerRFQsInline />;
}

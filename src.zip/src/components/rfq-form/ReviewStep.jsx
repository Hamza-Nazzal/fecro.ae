// src/components/rfq-form/ReviewStep.jsx
import React from "react";
import "./review-step.css";

import { formatDMY, addDays } from "../../utils/date";

export default function ReviewStep({ items = [], orderDetails = {}, meta = {} }) {
  const issuedAt = meta.issuedAt || new Date();
  const validDays = Number(meta.validDays ?? 14);
  const deadline = addDays(issuedAt, validDays);

  const city = meta.location?.city || "—";
  const emirate = meta.location?.emirate || "—"; // UI label: Emirate
  const country = meta.location?.country || "—";

  const rfqId = meta.publicId || meta.rfqId || "RFQ-—";

  const deliveryTimeline = orderDetails.deliveryTimeline || "Standard";
  const deliveryTerms = orderDetails.deliveryTerms || "EXW";
  const paymentTerms = orderDetails.paymentTerms || "Net-30";

  return (
    <div className="rfq-review">
      {/* v6-style header */}
      <header className="header text-center mb-7">
        <h1 className="title">REQUEST FOR QUOTATION (RFQ)</h1>
        <div className="muted">
          {rfqId} · Date Issued: {formatDMY(issuedAt)}
        </div>
      </header>

      <h2 className="section-title">1. RFQ Summary</h2>
      <table className="kv">
        <tbody>
          <tr>
            <th>Customer</th>
            <td><em>Your company details are only revealed after you accept a quotation.</em></td>
          </tr>
          <tr>
            <th>Location</th>
            <td>{city}, {emirate}, {country}</td>
          </tr>
          <tr>
            <th>RFQ Valid for</th>
            <td>{validDays}-days</td>
          </tr>
          <tr>
            <th>Total Items</th>
            <td>{items.length} {items.length === 1 ? "product" : "products"}</td>
          </tr>
        </tbody>
      </table>

      <h2 className="section-title">2. Requested Items</h2>
      <div className="items">
        {items.map((it, idx) => (
          <div key={it.id || idx} className="item">
            <div className="row">
              {/* Left: breadcrumb + arrow-under-leaf + product */}
              <div className="col">
                <div className="cat-wrap">
                  <div className="breadcrumb">{it.categoryPath || "—"}</div>
                  <div className="breadcrumb-empty" />
                  <div className="leaf-arrow">└──&gt;</div>
                  <div className="product-line">
                    <strong>Product name</strong>
                    {it.name ? <>: <strong>{it.name}</strong></> : null}
                  </div>
                </div>
              </div>

              {/* Mid: Qty card beside product (bold label and number) */}
              <div className="qty">
                <div className="qty-card">
                  <span className="lbl">Qty:</span>
                  <span className="num">{it.quantity ?? 1}</span>
                </div>
              </div>

              {/* Right: seller panel present but hidden by default */}
              <aside className="seller-panel">
                Right-side space reserved for seller usage widgets / price input.
              </aside>
            </div>

            {/* Specs below, full width */}
            <div className="specs">
              <h4>Specifications for this product</h4>
              {Array.isArray(it.specs) && it.specs.length ? (
                <ul className="spec-list">
                  {it.specs.map((s, i) => (
                    <li key={i}>{s.label}: {String(s.value)}</li>
                  ))}
                </ul>
              ) : (
                <div className="muted">—</div>
              )}
            </div>
          </div>
        ))}
      </div>

      <h2 className="section-title">3. Order &amp; Payment Terms</h2>
      <table className="terms">
        <tbody>
          <tr>
            <th>Delivery Timeline</th>
            <td>{deliveryTimeline}</td>
          </tr>
          <tr>
            <th>Delivery Terms</th>
            <td>{deliveryTerms}</td>
          </tr>
          <tr>
            <th>Payment Terms</th>
            <td>{paymentTerms}</td>
          </tr>
        </tbody>
      </table>

      <h2 className="section-title">4. Submission Instructions</h2>
      <p className="mb-8">
        Please submit your quotation before <strong>{formatDMY(deadline)}</strong> on <strong>fecro.ae</strong>.
      </p>
    </div>
  );
}
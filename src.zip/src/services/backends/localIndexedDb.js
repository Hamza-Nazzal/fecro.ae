//src/services/backends/localIndexedDb.js
// Thin wrapper to preserve original import path during refactor
export * from './local-idb/index'

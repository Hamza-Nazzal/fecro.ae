//src/components/rfq-form/spec-editor/index.js

export { default } from './SpecEditor.jsx';

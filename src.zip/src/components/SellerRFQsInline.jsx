// src/components/SellerRFQsInline.jsx
// Shows RFQs inside your existing Seller "Browse" tab, upgraded to the new UX.
// Keeps your data services/hooks and paging; swaps the list for RFQCard + RFQToolbar.

import React, { useEffect, useMemo, useRef, useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { listRFQsForCards } from "../services/rfqService/reads";
import { listMyQuotedRFQIds } from "../services/quotationsService";
import RFQCard from "./RFQCard";          // Step 1 component (card with progressive disclosure)
import RFQToolbar from "./RFQToolbar";    // sticky toolbar (search, open-only, sort, density)
import { useNavigate } from "react-router-dom";


export default function SellerRFQsInline() {
  const { user } = useAuth();
  const navigate = useNavigate();
  // UI state
  const [query, setQuery] = useState("");
  const [onlyOpen, setOnlyOpen] = useState(true); // server is fixed to open; we keep this for future flexibility
  const [hideQuoted, setHideQuoted] = useState(true);
  const [dense, setDense] = useState(false);
  const [sort, setSort] = useState("posted_desc"); // posted_desc | posted_asc | deadline_asc | views_desc

  // data state
  const [rfqs, setRfqs] = useState([]);
  const [quotedSet, setQuotedSet] = useState(() => new Set());

  // load state
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // paging
  const [page, setPage] = useState(1);
  const pageSize = 20;

  // request id to avoid strict-mode double mount issues & overlap
  const reqIdRef = useRef(0);

  // Load RFQs (light view; no heavy joins)
  useEffect(() => {
    let alive = true;
    const myReq = ++reqIdRef.current;

    (async () => {
      try {
        setLoading(true);
        setError(null);

        const res = await listRFQsForCards({
          onlyOpen: true, // server-side filter (kept ON as before)
          page,
          pageSize,
        });

        if (!alive || myReq !== reqIdRef.current) return;

        // Accept either array or { data }
        const data = Array.isArray(res) ? res : res?.data;
        setRfqs(data || []);
      } catch (e) {
        if (!alive || myReq !== reqIdRef.current) return;
        setError(e?.message || String(e));
        setRfqs([]);
      } finally {
        if (!alive || myReq !== reqIdRef.current) return;
        setLoading(false);
      }
    })();

    return () => {
      alive = false;
    };
  }, [page, pageSize]);

  // Load my quoted RFQ ids (once per user; refresh if user changes)
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const ids = await listMyQuotedRFQIds();
        if (!alive) return;
        setQuotedSet(ids);
      } catch (e) {
        // non-fatal
        // eslint-disable-next-line no-console
        console.warn("Failed to load quoted RFQ ids:", e?.message || e);
      }
    })();
    return () => {
      alive = false;
    };
  }, [user?.id]);

  // Refresh quoted-set when a quotation is submitted elsewhere
  useEffect(() => {
    const onSubmitted = async () => {
      try {
        const ids = await listMyQuotedRFQIds();
        setQuotedSet(ids);
      } catch (e) {
        // eslint-disable-next-line no-console
        console.warn("Refresh quoted ids failed:", e?.message || e);
      }
    };
    window.addEventListener("quotation:submitted", onSubmitted);
    return () => window.removeEventListener("quotation:submitted", onSubmitted);
  }, []);

  // Reset to page 1 when query changes (better UX)
  useEffect(() => {
    setPage(1);
  }, [query]);

  // Client search/filter/sort on the currently loaded page
  const filteredAndSorted = useMemo(() => {
    const q = (query || "").trim().toLowerCase();
    let base = rfqs;

    // search: title, publicId, categoryPath, item names (if present)
    if (q) {
      base = base.filter((r) => {
        const t = (r.title || "").toLowerCase();
        const id = (r.publicId || r.id || "").toString().toLowerCase();
        const c = (r.categoryPath || "").toLowerCase();
        const itemHit = Array.isArray(r.items)
          ? r.items.some((it) => (it?.name || "").toLowerCase().includes(q))
          : false;
        return t.includes(q) || id.includes(q) || c.includes(q) || itemHit;
      });
    }

    // hide already quoted RFQs (by this seller)
    if (hideQuoted && quotedSet && quotedSet.size) {
      base = base.filter((r) => !quotedSet.has(r.id));
    }

    // (Optional) local only-open filter if ever needed (server already filters)
    if (onlyOpen) {
      base = base.filter((r) => (r.status || "open") === "open");
    }

    // Sorting
    const sorterMap = {
      posted_desc: (a, b) => new Date(b.postedAt || 0) - new Date(a.postedAt || 0),
      posted_asc: (a, b) => new Date(a.postedAt || 0) - new Date(b.postedAt || 0),
      deadline_asc: (a, b) => new Date(a.deadline || 0) - new Date(b.deadline || 0),
      views_desc: (a, b) => (b.views || 0) - (a.views || 0),
    };
    const sorter = sorterMap[sort] || (() => 0);

    return [...base].sort(sorter);
  }, [rfqs, query, hideQuoted, quotedSet, onlyOpen, sort]);

  const seller = useMemo(
    () => ({ id: user?.id, name: user?.name, company: user?.company }),
    [user]
  );

  return (
    <div className="p-4">
      <h2 className="mb-1 text-lg font-semibold">RFQs</h2>
      <p className="mb-3 text-sm text-slate-600">
        Browse requests and send quotations. Use search, filters, and compact mode for faster scanning.
      </p>

      <RFQToolbar
        total={filteredAndSorted.length}
        query={query}
        setQuery={setQuery}
        onlyOpen={onlyOpen}
        setOnlyOpen={setOnlyOpen}
        sort={sort}
        setSort={setSort}
        dense={dense}
        setDense={setDense}
      />

      {/* Extra toggle row for seller-specific filter */}
      <div className="mb-3 flex items-center justify-between text-sm">
        <label className="inline-flex items-center gap-2 text-slate-700">
          <input
            type="checkbox"
            checked={hideQuoted}
            onChange={(e) => setHideQuoted(e.target.checked)}
            className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-400"
          />
          Hide already quoted
        </label>
        <div className="text-slate-500">
          Page {page} • Showing {loading ? "…" : filteredAndSorted.length} items
        </div>
      </div>

      {error && (
        <div className="mb-3 rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700">
          {String(error?.message || error)}
        </div>
      )}

      {loading ? (
        <div className="text-slate-500">Loading…</div>
      ) : filteredAndSorted.length ? (
        <>
          <div className={dense ? "grid gap-2" : "grid gap-3"}>
            {filteredAndSorted.map((rfq) => (
              <RFQCard
                key={rfq.id || rfq.publicId}
                rfq={rfq}
                seller={seller}
                onSendQuote={(r) => {
                  // TODO: route to your quotation composer (keep console for now)
                  // e.g., navigate(`/seller/quote/${r.id || r.publicId}`)
                  // eslint-disable-next-line no-console
                  const rid = r.id || r.publicId;
                  navigate(`/seller/quote/${encodeURIComponent(rid)}`);
                  console.log("Send Quote", r);
                }}
              />
            ))}
          </div>

          {/* Simple pager */}
          <div className="mt-6 flex items-center justify-between">
            <button
              className="px-3 py-1.5 rounded-md border text-sm disabled:opacity-50"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={loading || page <= 1}
            >
              Prev
            </button>
            <div className="text-sm text-slate-600">Page {page}</div>
            <button
              className="px-3 py-1.5 rounded-md border text-sm disabled:opacity-50"
              onClick={() => setPage((p) => p + 1)}
              // heuristic: when server returns < pageSize, likely no next page
              disabled={loading || rfqs.length < pageSize}
            >
              Next
            </button>
          </div>
        </>
      ) : (
        <div className="rounded-xl border bg-white p-8 text-center shadow-sm">
          <div className="text-slate-500">No requests to show.</div>
          {(onlyOpen || hideQuoted) && (
            <p className="mt-2 text-sm text-slate-400">
              Try relaxing filters above to see more results.
            </p>
          )}
        </div>
      )}
    </div>
  );
}

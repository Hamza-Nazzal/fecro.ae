// src/components/BuyerRFQsInline.jsx
// Buyer-facing list using the same UX: toolbar + RFQCard with buyer CTA.
// Assumes your reads service can fetch the current buyer's RFQs.
// If not, we filter client-side by buyerId.

import React, { useEffect, useMemo, useRef, useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import RFQToolbar from "./RFQToolbar";
import RFQCard from "./RFQCard";
import { listRFQsForCards } from "../services/rfqService/reads";
import { useNavigate } from "react-router-dom";



export default function BuyerRFQsInline() {
  const { user } = useAuth();
  const navigate = useNavigate();

  // UI state
  const [query, setQuery] = useState("");
  const [onlyOpen, setOnlyOpen] = useState(false); // buyers may want to see closed/awarded too
  const [dense, setDense] = useState(false);
  const [sort, setSort] = useState("posted_desc");

  // data
  const [rfqs, setRfqs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // paging
  const [page, setPage] = useState(1);
  const pageSize = 20;
  const reqIdRef = useRef(0);

  // Load buyer's RFQs
  useEffect(() => {
    let alive = true;
    const myReq = ++reqIdRef.current;

    (async () => {
      try {
        setLoading(true);
        setError(null);

        // Try server-side filter if supported by your service implementation:
        const res = await listRFQsForCards({
          buyerId: user?.id,   // if your backend supports this
          onlyOpen: onlyOpen ? true : undefined, // optional
          page,
          pageSize,
        });

        if (!alive || myReq !== reqIdRef.current) return;

        const data = Array.isArray(res) ? res : res?.data;
        let rows = data || [];

        // Fallback: ensure only my RFQs if server didn't filter
        if (user?.id) {
          rows = rows.filter((r) => r.buyerId === user.id || r.createdBy === user.id || r.ownerId === user.id);
        }

        setRfqs(rows);
      } catch (e) {
        if (!alive || myReq !== reqIdRef.current) return;
        setError(e?.message || String(e));
        setRfqs([]);
      } finally {
        if (!alive || myReq !== reqIdRef.current) return;
        setLoading(false);
      }
    })();

    return () => {
      alive = false;
    };
  }, [user?.id, page, pageSize, onlyOpen]);

  // Reset page when query changes
  useEffect(() => setPage(1), [query]);

  // Client search/sort
  const filteredAndSorted = useMemo(() => {
    const q = (query || "").trim().toLowerCase();
    let base = rfqs;

    if (q) {
      base = base.filter((r) => {
        const t = (r.title || "").toLowerCase();
        const id = (r.publicId || r.id || "").toString().toLowerCase();
        const c = (r.categoryPath || "").toLowerCase();
        const itemHit = Array.isArray(r.items)
          ? r.items.some((it) => (it?.name || "").toLowerCase().includes(q))
          : false;
        return t.includes(q) || id.includes(q) || c.includes(q) || itemHit;
      });
    }

    if (onlyOpen) {
      base = base.filter((r) => (r.status || "open") === "open");
    }

    const sorterMap = {
      posted_desc: (a, b) => new Date(b.postedAt || 0) - new Date(a.postedAt || 0),
      posted_asc: (a, b) => new Date(a.postedAt || 0) - new Date(b.postedAt || 0),
      deadline_asc: (a, b) => new Date(a.deadline || 0) - new Date(b.deadline || 0),
      views_desc: (a, b) => (b.views || 0) - (a.views || 0),
    };
    const sorter = sorterMap[sort] || (() => 0);

    return [...base].sort(sorter);
  }, [rfqs, query, onlyOpen, sort]);

  return (
    <div className="p-4">
      <h2 className="mb-1 text-lg font-semibold">My RFQs</h2>
      <p className="mb-3 text-sm text-slate-600">
        Review and manage your requests. Search, filter, and sort to find RFQs quickly.
      </p>

      <RFQToolbar
        total={filteredAndSorted.length}
        query={query}
        setQuery={setQuery}
        onlyOpen={onlyOpen}
        setOnlyOpen={setOnlyOpen}
        sort={sort}
        setSort={setSort}
        dense={dense}
        setDense={setDense}
      />

      {error && (
        <div className="mb-3 rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700">
          {String(error?.message || error)}
        </div>
      )}

      {loading ? (
        <div className="text-slate-500">Loading…</div>
      ) : filteredAndSorted.length ? (
        <>
          <div className={dense ? "grid gap-2" : "grid gap-3"}>
            {filteredAndSorted.map((rfq) => (
              <RFQCard
                key={rfq.id || rfq.publicId}
                rfq={rfq}
                role="buyer"
                ctaLabel="View / Manage"
                onPrimary={(r) => {
                  // TODO: navigate to buyer RFQ details page
                  // e.g., navigate(`/buyer/rfq/${r.id || r.publicId}`)
                  // eslint-disable-next-line no-console
                  console.log("Open RFQ", r);
                  const rid = r.id || r.publicId;
                  navigate(`/buyer/rfq/${encodeURIComponent(rid)}`);
                }}
              />
            ))}
          </div>

          {/* Simple pager */}
          <div className="mt-6 flex items-center justify-between">
            <button
              className="px-3 py-1.5 rounded-md border text-sm disabled:opacity-50"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={loading || page <= 1}
            >
              Prev
            </button>
            <div className="text-sm text-slate-600">Page {page}</div>
            <button
              className="px-3 py-1.5 rounded-md border text-sm disabled:opacity-50"
              onClick={() => setPage((p) => p + 1)}
              disabled={loading || rfqs.length < pageSize}
            >
              Next
            </button>
          </div>
        </>
      ) : (
        <div className="rounded-xl border bg-white p-8 text-center shadow-sm">
          <div className="text-slate-500">No RFQs yet.</div>
        </div>
      )}
    </div>
  );
}

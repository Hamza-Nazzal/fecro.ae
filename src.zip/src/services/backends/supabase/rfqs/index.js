// src/services/backends/supabase/rfqs/index.js
import { mapRowsToJs, listRFQRows, insertRFQ, patchRFQ, removeRFQ } from "./base";
import { upsertItem, upsertItemSpecs, deleteSpecsNotIn, cascadeDeleteItems, bulkInsertItemSpecs } from "./items";
import { normalizeSpecsInput } from "../../../../utils/rfqSpecs";
import { getRFQHydrated } from "./hydrate";

/** List top-level RFQs (no hydration) */
export async function listRFQs(opts = {}) {
  const rows = await listRFQRows(opts);
  return mapRowsToJs(rows);
}

/** List my RFQs (top-level) */
export async function listMyRFQs(userId) {
  const rows = await listRFQRows({ userId });
  return mapRowsToJs(rows);
}

/** Full read (RFQ + items + specs) */
export async function getRFQ(id) {
  return await getRFQHydrated(id);
}

/** Create RFQ and (optionally) its child items/specs; return hydrated */
export async function createRFQ(rfqJs) {
  const now = new Date().toISOString();
  const rfqRow = await insertRFQ(rfqJs);

  if (Array.isArray(rfqJs.items) && rfqJs.items.length) {
    const itemSpecsMap = {};
    
    // First, insert all items and collect specs for bulk insert
    for (const it of rfqJs.items) {
      const itemId = await upsertItem(it, rfqRow.id, now);
      
      // Collect specifications for bulk insert if they exist and are an array
      const normalizedSpecs = normalizeSpecsInput(it.specifications);
      if (normalizedSpecs.length > 0) {
        itemSpecsMap[itemId] = normalizedSpecs;
      }
    }
    
    // Bulk insert all specs at once
    if (Object.keys(itemSpecsMap).length > 0) {
      await bulkInsertItemSpecs(itemSpecsMap);
    }
  }
  return await getRFQHydrated(rfqRow.id);
}

/** Update RFQ; if updates.items provided, upsert + delete removed specs; return hydrated */
export async function updateRFQ(id, updatesJs) {
  const now = new Date().toISOString();
  // Patch top-level first (if any fields present)
  const top = { ...updatesJs };
  delete top.items;
  if (Object.keys(top).length) {
    await patchRFQ(id, top);
  }

  // Touch children only if provided
  if (Array.isArray(updatesJs.items)) {
    for (const it of updatesJs.items) {
      const itemId = await upsertItem(it, id, now);
      if (Object.prototype.hasOwnProperty.call(it, "specifications")) {
        const incoming = await upsertItemSpecs(itemId, it.specifications ?? null, now);
        // Delete removed keys (parity with previous implementation)
        await deleteSpecsNotIn(itemId, incoming);
      }
    }
  }

  return await getRFQHydrated(id);
}

/** Delete RFQ with manual cascade */
export async function deleteRFQ(id) {
  await cascadeDeleteItems(id);
  await removeRFQ(id);
  return true;
}

export { seedDemoRFQs } from "./seed";

// src/components/RFQToolbar.jsx
import React from "react";
import { Search, Filter, ArrowUpDown } from "lucide-react";

export default function RFQToolbar({ total, query, setQuery, onlyOpen, setOnlyOpen, sort, setSort, dense, setDense }) {
  return (
    <div className="sticky top-0 z-10 -mx-4 mb-3 border-b border-slate-200 bg-white/80 px-4 py-3 backdrop-blur">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="pointer-events-none absolute left-2 top-2.5 h-4 w-4 text-slate-400" />
          <input
            placeholder="Search title, RFQ ID, item name…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full rounded-xl border border-slate-300 bg-white pl-8 pr-3 py-2 text-sm outline-none focus:border-blue-400"
          />
        </div>

        <button
          className="inline-flex items-center gap-1 rounded-xl border border-slate-300 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50"
          onClick={() => setOnlyOpen((v) => !v)}
        >
          <Filter className="h-4 w-4" /> {onlyOpen ? "Open only" : "All statuses"}
        </button>

        <select
          value={sort}
          onChange={(e) => setSort(e.target.value)}
          className="rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm"
        >
          <option value="posted_desc">Newest</option>
          <option value="posted_asc">Oldest</option>
          <option value="deadline_asc">Deadline (soonest)</option>
          <option value="views_desc">Views (high→low)</option>
        </select>

        <button
          onClick={() => setDense((d) => !d)}
          className="inline-flex items-center gap-1 rounded-xl border border-slate-300 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50"
        >
          <ArrowUpDown className="h-4 w-4" /> {dense ? "Comfortable" : "Compact"}
        </button>

        <div className="ml-auto text-sm text-slate-500">{total} RFQs</div>
      </div>
    </div>
  );
}
